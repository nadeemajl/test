<!--
Grakn - A Distributed Semantic Database
Copyright (C) 2016  Grakn Labs Limited

Grakn is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Grakn is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Grakn. If not, see <http://www.gnu.org/licenses/gpl.txt>.
-->

<template>
<section class="wrapper">
    <!-- Main content-->
    <section class="content">
        <div class="content-404">
          <div class="inside">
            PAGE NOT FOUND - 404 Go back
            <router-link tag="a" to="/">home.</router-link>
          </div>
        </div>
    </section>
    <!-- End main content-->

</section>
</template>

<style>
.content-404 {
    display: flex;
    align-items: center;
    justify-content: center;
    flex: 1;
}

</style>

<script>

</script>
